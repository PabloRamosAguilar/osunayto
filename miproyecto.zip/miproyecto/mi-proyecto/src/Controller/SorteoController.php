<?php
// src/Controller/SorteoController.php
namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class SorteoController extends AbstractController
{

    public function index()
    {

        return $this->render('sorteo/estructuraBase.html.twig', [
            
        ]);
    }
    public function suma($numero1, $numero2)
    {
        $suma = $numero1 + $numero2;
        return $this->render('sorteo/suma.html.twig', [
            'suma' => $suma,
            'numero1' => $numero1,
            'numero2' => $numero2,
        ]);
    }

    public function numero($maximo)
    {
        if (!ctype_digit($maximo)) {
            return $this->redirectToRoute('app_numero_sorteo', array('maximo' => 0));
        }

        $numero = random_int(0, $maximo);
        return $this->render('sorteo/numero.html.twig', [
            'numero' => $numero,
            'maximo' => $maximo,
        ]);
    }

    public function euromillones()
    {
        $arrays = array(
           0 => random_int(0,50),
           1 => random_int(0,50),
           2 => random_int(0,50),
           3 => random_int(0,50),
           4 => random_int(0,50),
           5 => random_int(1,12),
           6 => random_int(1,12),
        );

        return $this->render('sorteo/euromillones.html.twig', [
            'array' => $arrays,
        ]);
    }
}
